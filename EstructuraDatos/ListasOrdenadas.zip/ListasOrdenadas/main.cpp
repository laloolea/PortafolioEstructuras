#include <iostream>
#include "ListaSimpleOrdenada.h"
#include <cstdlib>
using namespace std;

int main () {
    ListaSimpleOrdenada <int>  lista;

    lista.AgregarElemento (5);

    lista.AgregarElemento (3);

    cout << lista;

    cout <<boolalpha<< lista.Buscar (3)<<endl;

    lista.EliminarElemento (3);
    return 0;
}