//
// Created by Eduardo Gonzalez Olea on 3/22/18.
//

#ifndef LISTASORDENADAS_LISTASIMPLEORDENADA_H
#define LISTASORDENADAS_LISTASIMPLEORDENADA_H

#include <cstdlib>
#include <iostream>
template <typename Tipo>
class ListaSimpleOrdenada;
template <typename Tipo>
std::ostream& operator<<(std::ostream & salida, const ListaSimpleOrdenada<Tipo>& c);

template <typename Tipo>
class ListaSimpleOrdenada {

    friend std::ostream & operator<< <>(std::ostream & salida, const ListaSimpleOrdenada<Tipo> &c);

public:

    ListaSimpleOrdenada();

    ListaSimpleOrdenada(const ListaSimpleOrdenada &c);

    ~ListaSimpleOrdenada ();


    void AgregarElemento(Tipo valor);

    bool EliminarElemento(Tipo valor);

    bool Buscar(Tipo valorB);

    void Vaciar();

    bool Vacia();

    int ObtenerTamanio();

    ListaSimpleOrdenada<Tipo> &operator=(const ListaSimpleOrdenada &c);

    //Imprimir lista, constructor por default, constructor de copias, destructor,
    // Agregar Elemento, Eliminar Elemento, buscarElemento, VaciarLista
    //ObtenernumElementos, revisar lista vacia.

private:

    struct Elemento{
        explicit Elemento(Tipo _valor, Elemento* _siguiente = NULL) : valor(_valor), siguiente(_siguiente){};

        Tipo valor;
        Elemento * siguiente;
    };

    int numElementos;
    Elemento *Primero;

};


template<typename Tipo>
ListaSimpleOrdenada<Tipo>::ListaSimpleOrdenada() :  numElementos(0) , Primero (NULL){

}
template<typename Tipo>
ListaSimpleOrdenada<Tipo>::ListaSimpleOrdenada (const ListaSimpleOrdenada &c): numElementos(0) , Primero (NULL) {
    *this = c;
}

template<typename Tipo>
ListaSimpleOrdenada<Tipo>::~ListaSimpleOrdenada () {
    Vaciar();
}



template<typename Tipo>
void ListaSimpleOrdenada<Tipo>::AgregarElemento (Tipo valor) {

    Elemento *aux = Primero, *ant = NULL;

    while(aux != NULL &&  aux -> valor <= valor){
        ant = aux;
        aux = aux ->siguiente;

    }
    Elemento * nuevo = new Elemento (valor,aux) ;
    ant == NULL ? Primero = nuevo : ant->siguiente =nuevo;

    ++numElementos;

}

template<typename Tipo>
bool ListaSimpleOrdenada<Tipo>::EliminarElemento (Tipo valor) {
    Elemento *aux = Primero, *ant = NULL;

    while(aux != NULL &&  aux ->valor != valor){
        ant = aux;
        aux = aux ->siguiente;

    }
    if(aux == NULL)return false;

    ant == NULL ? Primero = aux->siguiente: ant->siguiente = aux->siguiente;
    delete aux;

    --numElementos;
    return true;
}

template<typename Tipo>
ListaSimpleOrdenada<Tipo> &ListaSimpleOrdenada<Tipo>::operator=(const ListaSimpleOrdenada &c)
{

    if(this == &c) return *this;

    Vaciar();


    Elemento *aux = c.Primero;

    while(aux != NULL ){
        AgregarElemento (aux->valor);
    }



    return *this;

}



template<typename Tipo>
void ListaSimpleOrdenada<Tipo>::Vaciar () {

    Elemento *aux;
    while(!Vacia()){
        aux= Primero;
        Primero = Primero->siguiente;
        delete aux;
    }
    numElementos = 0;
}

template<typename Tipo>
bool ListaSimpleOrdenada<Tipo>::Vacia () {
    return Primero==NULL;
}
template<typename Tipo>
std::ostream &operator<<(std::ostream &salida, const ListaSimpleOrdenada <Tipo> &c) {

    if(c.Primero == NULL){
        salida << "La cola esta vacia";
        return salida;
    }
    struct ListaSimpleOrdenada<Tipo>::Elemento * aux = c.Primero;
    salida << "Primero -> ";

    while(aux!=  NULL){
        salida << "[" << aux -> valor << "] , ";
        aux = aux -> siguiente;
    }
    salida << "\b\b ";

    //salida << "[" << aux -> valor << "] , ";

    return salida << std::endl;

}

template<typename Tipo>
int ListaSimpleOrdenada<Tipo>::ObtenerTamanio () {
    return numElementos;
}

template<typename Tipo>
bool ListaSimpleOrdenada<Tipo>::Buscar (Tipo valorB) {
    Elemento *aux = Primero;

    if(aux==NULL)return false;
    while(aux != NULL ){
        if(aux->valor==valorB)return true;
        aux = aux->siguiente;
    }
    return false;
}


#endif //LISTASORDENADAS_LISTASIMPLEORDENADA_H
