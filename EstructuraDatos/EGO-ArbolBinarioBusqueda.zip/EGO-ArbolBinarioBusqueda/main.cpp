#include <iostream>
#include <cstdlib>
#include <fstream>
#include "ABB.h"
#include "CapturaSegura.h"

using namespace std;


int main () {
    ABB<string> arbolPalabrasReservadas;
    ABB<string> arbolPalabrasReservadasEnCodigo;
    string palabraReservada;
    string palabraABuscar;

    string ruta;

    CapturaDato ("Por favor ingrese su ruta del archivo a buscar palabras reservadas: ",ruta);


    ifstream entrada("/Users/eduardogonzalez/Desktop/EstructuraDatos/EGO-ArbolBinarioBusqueda/PalabrasReservadas.txt");
    ifstream entrada2(/*"/Users/eduardogonzalez/Desktop/EstructuraDatos/EGO-ArbolBinarioBusqueda/Cola.h"*/ruta);

    if (!entrada || !entrada2){
        cout << "No se pudo abrir el archivo por problemas de fuerza mayor" << endl;
            return 0;
    }

    try {
        //bloque de codigo que lee archivo de palabrasReservadas para guardar en un arbol de busqueda
        if (entrada.is_open()){
            while (getline(entrada,palabraReservada)){
                if (entrada.bad()) throw "Ocurrio una falla irrecuperable en el flujo del archivo";
                if (entrada.fail()) throw "Los datos del archivo no tienen el formato esperado";
                arbolPalabrasReservadas.Agregar(palabraReservada);
            }
            entrada.close();
            }
        cout << "Buscando palabras reservadas en archivo dado..." << endl;
        //bloque de codigo que abre el archivo fuente para leer y buscar las palabras reservadas dentro de el
        if (entrada2.is_open()){
            while (!entrada2.eof()){
                if (entrada2.bad()) throw "Ocurrio una falla irrecuperable en el flujo del archivo";
                if (entrada2.fail()) throw "Los datos del archivo no tienen el formato esperado";
                entrada2 >> palabraABuscar;
                //compara cada palabra con el arbol de las palabras reservadas, si hay un verdadero es decir que encontro una
                //palabra reservada dentro del codigo, lo cual la guarda en el otro arbol
                if (arbolPalabrasReservadas.Buscar(palabraABuscar)){
                    arbolPalabrasReservadasEnCodigo.Agregar(palabraABuscar);
                }
            }
        }
    entrada2.close();
    cout << "Palabras reservadas encontradas: ";
    arbolPalabrasReservadasEnCodigo.ImprimirAscendente();
    } catch ( const char *exc){
        cout << "Error: " << exc << endl;
    }

    return 0;
}


