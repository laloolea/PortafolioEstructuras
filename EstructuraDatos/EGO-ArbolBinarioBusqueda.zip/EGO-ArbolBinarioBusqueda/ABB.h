//
// Created by Eduardo Gonzalez Olea on 4/30/18.
//

#ifndef EGO_ARBOLBINARIOBUSQUEDA_ARBOLBINARIOBUSQUEDA_H
#define EGO_ARBOLBINARIOBUSQUEDA_ARBOLBINARIOBUSQUEDA_H

#include <cstdlib>
#include <iostream>
#include "Cola.h"
template <typename Tipo>
class ABB;

template <typename Tipo=int>
class ABB{
public:
    ABB();
    ~ABB();
    ABB(const ABB<Tipo> &c);

    ABB<Tipo> &operator=(const ABB<Tipo> &c);

    bool Agregar(Tipo valor);

    bool EliminarElemento(Tipo _valor);


    bool EstaVacio() const;

    void Imprimir() const;

    int ObtenerNumElementos() const;

    int ObtenerTamanio()const;

    bool Buscar(Tipo valor)const;

    void Vaciar();
    void ImprimirAscendente() const ;
    void ImprimirDescendente()const;

    void ImprimirPorNiveles()const;

private:
    int numElementos;

    struct Elemento{
        explicit Elemento(Tipo _valor, Elemento* _hijoIzq = NULL,Elemento * _hijoDer =  NULL) :
                valor(_valor), hijoIzq(_hijoIzq),hijoDer(_hijoDer) {};

        Tipo valor;
        Elemento * hijoIzq ;
        Elemento * hijoDer ;
    };

    Elemento *raiz;

    bool Agregar(Tipo _valor , Elemento *& _raiz);
    //Inorden
    void ImprimirAscendente(Elemento * _raiz) const ;
     void Intercambia(Tipo &a, Tipo &b);
    // Inorden inverso
    void ImprimirDescendente(Elemento * _raiz)const;
    //Recorrido por niveles iterativos

    //void ImprimirPorNiveles() const;
    void Vaciar( Elemento *& _raiz);

    Elemento* BuscarMayor(Elemento* _raiz);

    bool EliminarElemento(Elemento *& _raiz, Tipo _valor);

    Elemento * BuscarPadreMayorMenores(Elemento * _raiz);
};

template <typename Tipo>
ABB<Tipo>::ABB() : numElementos(0), raiz(NULL){}


template<typename Tipo>
ABB<Tipo>::ABB (const ABB<Tipo> &c) : numElementos (),raiz(NULL) {
    *this=c;
}

template <typename Tipo>
ABB<Tipo>::~ABB()
{
    Vaciar(raiz);
}


template <typename Tipo>
bool ABB<Tipo>::Agregar(Tipo valor)
{
    numElementos++;
    return Agregar(valor,raiz);

}

template<typename Tipo>
bool ABB<Tipo>::Agregar (Tipo _valor , ABB::Elemento *& _raiz){

    if(_raiz==NULL) {
        _raiz= new Elemento(_valor);
        return true;
    }
    if( _valor == _raiz->valor) return false;


     return _valor < _raiz->valor ? Agregar(_valor,_raiz->hijoIzq) : Agregar(_valor,_raiz->hijoDer);


}


template<typename Tipo>
bool ABB<Tipo>::EliminarElemento(Tipo _valor)
{


    //Iterativo
    /*
    Elemento *aux=raiz,*padre = NULL;

    while(aux!=NULL && aux -> valor != _valor){
        padre=aux;
        aux= _valor < aux -> valor ? aux -> hijoIzq : aux -> hijoDer;
    }

    if(aux == NULL ) return false;

    if(aux->hijoIzq==NULL && aux -> hijoDer == NULL)
        padre ==NULL ? raiz=NULL: padre -> hijoIzq == aux ? padre -> hijoIzq = NULL : padre -> hijoDer = NULL;


    else if (aux->hijoIzq !=NULL && aux -> hijoDer == NULL)

        padre == NULL ? raiz = aux -> hijoIzq : padre -> hijoIzq == aux ? padre -> hijoIzq = aux->hijoIzq :
                        padre -> hijoDer = aux-> hijoIzq;

    else if (aux->hijoIzq == NULL & aux -> hijoDer !=NULL)
        padre == NULL ? raiz = aux -> hijoDer : padre -> hijoIzq == aux ? padre -> hijoIzq = aux -> hijoDer :
                        padre->hijoDer = aux->hijoDer;

    else{
        Elemento * mayor= BuscarMayor(aux->hijoIzq);
        mayor -> hijoDer = aux->hijoDer;
        padre == NULL ? raiz= aux-> hijoIzq : padre->hijoIzq == aux ? padre->hijoIzq = aux -> hijoIzq :
                        padre->hijoDer =aux->hijoIzq;

    }
    delete aux;
    --numElementos;
    return true;
     */
}

//Eliminar Recursivo
template<typename Tipo>
bool ABB<Tipo>::EliminarElemento (ABB::Elemento *&_raiz , Tipo _valor) {
    if(_raiz == NULL) return false;

    if(_valor == _raiz -> valor){
        Elemento * aux = _valor;
        if(_raiz -> hijoIzq == NULL && _raiz -> hijoDer == NULL)_raiz = NULL;
        else if(_raiz -> hijoIzq != NULL  && _raiz -> hijoDer == NULL)
            _raiz = _raiz -> hijoIzq;
        else if(_raiz -> hijoIzq == NULL && _raiz ->hijoDer !=NULL)
            _raiz = _raiz -> hijoDer;
        else{
            Elemento * padre = BuscarPadreMayorMenores(_raiz);
            Intercambia(_raiz->valor,padre == _raiz ? _raiz -> hijoIzq -> valor : padre->hijoDer->valor);
            return Elemento (padre == _raiz ? _raiz ->hijoIzq : padre -> hijoDer, _valor);
        }
        delete aux;
        --numElementos;
        return true;
    }

    return _valor < _raiz -> valor ? EliminarElemento(_raiz -> hijoIzq,_valor): EliminarElemento(_raiz -> hijoDer, _valor);

}


template <typename Tipo>
bool ABB<Tipo>::EstaVacio()  const {
    return raiz==NULL;
}

template <typename Tipo>
void ABB<Tipo>::Imprimir() const
{
    ImprimirAscendente(raiz);
    std::cout<<"\b\b";

}
//Publica
template<typename Tipo>
void ABB<Tipo>::ImprimirAscendente () const
{
    ImprimirAscendente(raiz);
}

//Inorden privada
template<typename Tipo>
void ABB<Tipo>::ImprimirAscendente (ABB::Elemento * _raiz) const
{
    if(_raiz != NULL){
        ImprimirAscendente (_raiz->hijoIzq);
        std::cout << _raiz ->valor<<", ";
        ImprimirAscendente (_raiz->hijoDer);
    }

}

//Publica
template<typename Tipo>
void ABB<Tipo>::ImprimirDescendente () const
{
    ImprimirDescendente (raiz);
}
//Inorden inverso privada
template<typename Tipo>
void ABB<Tipo>::ImprimirDescendente (ABB::Elemento *_raiz) const
{
    if(_raiz != NULL){
        ImprimirDescendente(_raiz->hijoDer);
        std::cout << _raiz ->valor<<", ";
        ImprimirDescendente (_raiz->hijoIzq);
    }

}

template<typename Tipo>
void ABB<Tipo>::ImprimirPorNiveles() const{
    if(raiz == NULL){
        std::cout << "El arbol est\240 vac\243o" << std::endl;
        return;
    }

    Cola<Elemento *> colaDeEspera;
    colaDeEspera.AgregarElemento(raiz);
    Elemento *aux;

    while(!colaDeEspera.Vacia()) {
        aux = colaDeEspera.EliminarElemento();
        std::cout << aux->valor << std::endl;
        if ( aux->hijoIzq != NULL )
            colaDeEspera.AgregarElemento(aux->hijoIzq);
        if ( aux->hijoDer != NULL )
            colaDeEspera.AgregarElemento(aux->hijoDer);
    }
}



template <typename Tipo>
void ABB<Tipo>::Intercambia(Tipo &a, Tipo &b)
{
    Tipo aux= a;
    a = b;
    b = aux;
}



template<typename Tipo>
ABB<Tipo> &ABB<Tipo>::operator=(const ABB<Tipo> &c){
    if(this == &c)
        return *this;

    Vaciar();

    if(c.EstaVacio())
        return *this;

    Cola<Elemento *> colaDeEspera;
    colaDeEspera.AgregarElemento(c.raiz);
    Elemento *aux;

    while(!colaDeEspera.Vacia()) {
        aux = colaDeEspera.EliminarElemento();
        Agregar(aux->valor);
        if ( aux->hijoIzq != NULL )
            colaDeEspera.AgregarElemento(aux->hijoIzq);
        if ( aux->hijoDer != NULL )
            colaDeEspera.AgregarElemento(aux->hijoDer);
    }
    return *this;
}
template<typename Tipo>
int ABB<Tipo>::ObtenerNumElementos() const
{
    return numElementos;
}

template<typename Tipo>
void ABB<Tipo>::Vaciar ()
{
    Vaciar(raiz);
    numElementos=0;

}

template<typename Tipo>
void ABB<Tipo>::Vaciar (ABB::Elemento *& _raiz)
{
    if (_raiz != NULL){
        Vaciar (_raiz->hijoIzq);
        Vaciar(_raiz->hijoDer);
        delete  _raiz;
        _raiz=NULL;

    }


}

template<typename Tipo>
int ABB<Tipo>::ObtenerTamanio () const
{
    return numElementos;
}

template<typename Tipo>
bool ABB<Tipo>::Buscar (Tipo valor) const
{
    Elemento *aux = raiz;
    while (aux!= NULL && aux->valor != valor){
        if (aux->valor > valor)aux= aux->hijoIzq;
        else aux= aux->hijoDer;
    }
    if (aux==NULL)return false;

    return true;
}


template<typename Tipo>
struct ABB<Tipo>::Elemento* ABB<Tipo>::BuscarMayor (Elemento *_raiz) {
    while(_raiz -> hijoDer != NULL){
        _raiz = _raiz->hijoDer;
    }
    return _raiz;
}

template<typename Tipo>
struct ABB<Tipo>::Elemento *ABB<Tipo>::BuscarPadreMayorMenores (Elemento * _raiz) {
    Elemento * padre = _raiz;
    raiz = raiz->hijoIzq;
    while(_raiz -> hijoDer != NULL){
        padre = _raiz;
        _raiz = _raiz->hijoDer;
    }
    return padre;
}


#endif //EGO_ARBOLBINARIOBUSQUEDA_ARBOLBINARIOBUSQUEDA_H



