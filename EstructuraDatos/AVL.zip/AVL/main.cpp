#include <iostream>
#include <cstdlib>
#include "AVL.h"
using namespace std;

int main () {

    AVL<int> arbolito;

    arbolito.Agregar (3);

    arbolito.Agregar (5);
    arbolito.Agregar (8);
    arbolito.Agregar (2);
    arbolito.Agregar (9);
    arbolito.Agregar (11);
    arbolito.Agregar (6);
    arbolito.Agregar (100);
    arbolito.Agregar (55);

    arbolito.ImprimirAscendente ();

    arbolito.EliminarElemento (8);
    arbolito.EliminarElemento (100);

    cout<<endl<<endl;
    arbolito.ImprimirAscendente();
    arbolito.Agregar (1);
    arbolito.Agregar (7);
    cout<<endl<<endl;
    arbolito.ImprimirAscendente ();
    return 0;
}
