//
// Created by Eduardo Gonzalez Olea on 1/29/18.
//

#include "Contador.h"


Contador::Contador(int _valor)
{
    valor = _valor;
}

Contador operator+(Contador i, Contador j)
{
    return Contador(i.valor + j.valor);
}

Contador operator*(Contador i, Contador j) {
    return Contador(i.valor*j.valor);
}

Contador operator/(Contador i, Contador j) {
    return Contador(i.valor/j.valor);
}

Contador operator-(Contador i, Contador j) {
    return Contador(i.valor-j.valor);
}
