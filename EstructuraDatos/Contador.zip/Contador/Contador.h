//
// Created by Eduardo Gonzalez Olea on 1/29/18.
//

#ifndef CONTADOR_CONTADOR_H
#define CONTADOR_CONTADOR_H


class Contador {
    friend Contador operator+ ( Contador i, Contador j);
    friend Contador operator* ( Contador i, Contador j);
    friend Contador operator/ ( Contador i, Contador j);
    friend Contador operator- ( Contador i, Contador j);

public:
    Contador();
    Contador(int _inicial);

protected:


private:
    int valor;
};


#endif //CONTADOR_CONTADOR_H
